package main.java.com.solvd;

public class Main {
    public static void main(String[] args) {

        Menu menu1 = new Menu();
        int value;
        do {

            value = menu1.mainMenu();

        } while (value != 0);

    }
}
