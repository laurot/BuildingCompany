package main.java.com.solvd.interfaces;

public interface IChange {
    
    //To change the default values of each class
    void changeBuildings();
    void changeServices();
    void changeWeather();
}
