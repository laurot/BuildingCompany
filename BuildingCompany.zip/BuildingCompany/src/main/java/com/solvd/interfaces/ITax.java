package main.java.com.solvd.interfaces;

public interface ITax {
    
    float tax(float price);
}
